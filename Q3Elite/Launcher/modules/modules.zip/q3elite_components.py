#!/usr/bin/env python3
# -*- coding: utf-8 -*-
r"""
Q3Elite component manager — Step 18B

Model:
  Basic              - always installed
  External Maps      - optional
  Music Playlist     - optional (tracks outside base 1..5)
  Autoexec Update    - optional policy: when OFF, updater must preserve autoexec.cfg

State:
  %APPDATA%\Quake 3 Elite\Launcher\components.json

Fresh Basic installation is manifest-driven and SHA-256 verified.
This first 18B backend intentionally favors correctness; the GUI can call the same
functions later. Components can be added/removed after installation.
"""

from __future__ import annotations

import argparse, hashlib, json, os, shutil, subprocess, sys, zipfile
from pathlib import Path, PurePosixPath

import pcloud_q3elite as pcloud
import q3elite_music as music
from download_tools import DownloadControl, downloader

ROOT = pcloud.ROOT
APPDATA = Path(os.environ.get("APPDATA", Path.home()))
STATE_FILE = APPDATA / "Quake 3 Elite" / "Launcher" / "components.json"
CACHE_DIR = APPDATA / "Quake 3 Elite" / "Launcher" / "cache"
TEMP_DIR = APPDATA / "Quake 3 Elite" / "Launcher" / "temp"
BASIC_ZIP = CACHE_DIR / "Q3Elite_Basic.zip"
BASIC_MAPS_ZIP = CACHE_DIR / "Q3Elite_Basic_Maps.zip"
MAPS_ZIP = CACHE_DIR / "Q3Elite_Maps.zip"

REMOTE_MANIFEST = "Q3Elite/Manifest.json"
REMOTE_VERSION = "Q3Elite/Version.json"
LOCAL_MANIFEST = ROOT / "Q3Elite" / "Manifest.json"
LOCAL_VERSION = ROOT / "Q3Elite" / "Version.json"

AUTOEXEC = "baseq3/mods/OSP/autoexec.cfg"
USER_CONFIG = "baseq3/mods/OSP/UserConfig.cfg"
MAP_PREFIX = "baseq3/maps/"
MUSIC_LOCAL_PREFIX = "baseq3/mods/osp/z-Music-Playlist-by-Mus1n.pk3dir/music/"
BASE_MUSIC = {f"{MUSIC_LOCAL_PREFIX}{n}.ogg".casefold() for n in range(1, 6)}

BASIC_QL_PREFIX = "baseq3/maps/QLmaps/"
BASIC_QL_MAP_NAMES = {name.casefold() for name in (
    "Arenagate.pk3", "Spillway.pk3", "Hearth.pk3", "Powerstation.pk3",
    "Eviscerated.pk3", "Forgotten.pk3", "Campgrounds.pk3",
    "Provinggrounds.pk3", "Retribution.pk3", "Brimstoneabbey.pk3",
    "Heroskeep.pk3", "Hellsgate.pk3", "Namelessplace.pk3",
    "Chemicalreaction.pk3", "Dredwerkz.pk3", "Verticalvengeance.pk3",
    "Lostworld.pk3", "Grimdungeons.pk3", "Demonkeep.pk3",
    "Fatalinstinct.pk3", "Cobaltstation.pk3", "Longestyard.pk3",
    "Spacechamber.pk3", "Terminalheights.pk3", "Theepicenter.pk3",
    "Beyondreality.pk3",
)}

def is_basic_ql_map(rel):
    p = norm(rel)
    cf = p.casefold()
    return cf.startswith(BASIC_QL_PREFIX.casefold()) and PurePosixPath(p).name.casefold() in BASIC_QL_MAP_NAMES


def norm(v):
    return str(PurePosixPath(str(v).replace("\\", "/").lstrip("/")))


def is_user_config(rel):
    return norm(rel).casefold() == USER_CONFIG.casefold()


def sha256_file(path, chunk=4 * 1024 * 1024, control=None):
    """SHA-256 with cooperative Pause/Resume/Cancel support."""
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        while True:
            if control is not None and not control.wait_if_paused():
                raise RuntimeError("Q3Elite verification cancelled.")
            block = f.read(chunk)
            if not block:
                break
            h.update(block)
    return h.hexdigest()


def atomic_json(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    os.replace(tmp, path)


def default_state():
    return {
        "format": 1,
        "basic": False,
        "external_maps": False,
        "music_playlist": False,
        "autoexec_update": False,
        "music_hashes": {},
        "external_maps_hashes": {},
    }


def load_state():
    if not STATE_FILE.is_file():
        return default_state()
    try:
        data = json.loads(STATE_FILE.read_text(encoding="utf-8-sig"))
        base = default_state()
        base.update(data if isinstance(data, dict) else {})
        if not isinstance(base.get("music_hashes"), dict):
            base["music_hashes"] = {}
        if not isinstance(base.get("external_maps_hashes"), dict):
            base["external_maps_hashes"] = {}
        return base
    except Exception:
        return default_state()


def save_state(state):
    atomic_json(STATE_FILE, state)


def fetch_json(remote):
    info = pcloud.resolve(pcloud.remote_for(remote))
    import urllib.request
    req = urllib.request.Request(info["url"], headers={"User-Agent": "Q3Elite-18B"})
    with urllib.request.urlopen(req, timeout=30) as r:
        return json.loads(r.read().decode("utf-8-sig"))


def remote_release():
    version = fetch_json(REMOTE_VERSION)
    manifest = fetch_json(REMOTE_MANIFEST)
    files = {norm(k): str(v).lower() for k, v in manifest.get("files", {}).items()}
    return version, manifest, files


def classify(rel):
    p = norm(rel)
    cf = p.casefold()
    if is_basic_ql_map(p):
        return "basic_map"
    if cf.startswith(MAP_PREFIX):
        return "maps"
    if cf == AUTOEXEC.casefold():
        return "autoexec"
    if cf in BASE_MUSIC:
        return "basic"
    return "basic"


def _is_official_q3_pak(path):
    p = norm(path).casefold()
    return (
        p.startswith("baseq3/pak")
        and p.endswith(".pk3")
        and len(p) == len("baseq3/pak0.pk3")
        and p[len("baseq3/pak")] in "012345678"
    )


def selected_basic_files(files, autoexec_update=False):
    # autoexec.cfg is still installed on first Basic install; the checkbox controls
    # whether later Q3Elite updates are allowed to replace it.
    #
    # Official id Software pak0.pk3-pak8.pk3 have a separate owner:
    # pak_verifier.py. They must never be resolved from the Q3Elite pCloud tree.
    return {
        p: h for p, h in files.items()
        if classify(p) in ("basic", "basic_map", "autoexec") and not _is_official_q3_pak(p)
    }


def selected_basic_map_files(files):
    return {p:h for p,h in files.items() if classify(p) == "basic_map"}

def selected_map_files(files):
    return {p:h for p,h in files.items() if classify(p) == "maps"}


def _size_index(remote_folder):
    """Build relative-path -> size from the cached pCloud tree; no download-URL calls."""
    return {
        norm(item["relative"]).casefold(): int(item.get("size", 0))
        for item in pcloud.list_folder(remote_folder, recursive=True)
    }


def catalog():
    version, manifest, files = remote_release()
    basic = selected_basic_files(files)
    maps = selected_map_files(files)

    # IMPORTANT: info/catalog must be cheap. The old 18B draft called resolve()
    # once per ~3000 files, which requested a temporary download URL for every file.
    # Here one cached showpublink tree is used and sizes are read directly from metadata.
    core_sizes = _size_index(pcloud.CORE)
    map_sizes = _size_index(pcloud.MAPS)

    def size_for(rel):
        remote = pcloud.remote_for(rel, is_map=classify(rel) == "maps")
        if classify(rel) == "maps":
            prefix = norm(pcloud.MAPS) + "/"
            key = norm(remote)[len(prefix):].casefold()
            return map_sizes.get(key, 0)

        # Base music 1..5 is hosted outside CORE.
        if norm(rel).casefold() in BASE_MUSIC:
            entry = pcloud.find(remote)
            return int(entry.get("size", 0))

        prefix = norm(pcloud.CORE) + "/"
        key = norm(remote)[len(prefix):].casefold()
        return core_sizes.get(key, 0)

    basic_bytes = sum(size_for(rel) for rel in basic)
    maps_bytes = sum(size_for(rel) for rel in maps)
    mi = music.describe()
    autoexec_key = next((rel for rel in files if rel.casefold() == AUTOEXEC.casefold()), None)
    autoexec_bytes = size_for(autoexec_key) if autoexec_key else 0
    return {
        "version": version,
        "manifest": manifest,
        "files": files,
        "basic_files": len(basic),
        "basic_bytes": basic_bytes,
        "maps_files": len(maps),
        "maps_bytes": maps_bytes,
        "music_tracks": mi["optional_tracks"],
        "music_bytes": mi["optional_bytes"],
        "autoexec_bytes": autoexec_bytes,
    }


def human(n):
    n=float(n)
    for u in ("B","KB","MB","GB","TB"):
        if n < 1024 or u=="TB":
            return f"{int(n)} B" if u=="B" else f"{n:.1f} {u}"
        n/=1024


def _download_managed(rel, digest, control=None, progress_callback=None):
    dest = ROOT / Path(rel)
    if is_user_config(rel) and dest.is_file():
        print(f"[preserved user config] {rel}")
        return False
    if dest.is_file() and sha256_file(dest, control=control).lower() == digest.lower():
        print(f"[current] {rel}")
        return False
    info = pcloud.resolve(pcloud.remote_for(rel, is_map=classify(rel) in ("maps", "basic_map")))
    dest.parent.mkdir(parents=True, exist_ok=True)
    print(f"[download] {rel} ({human(info['size'])})")
    result = downloader(
        info["url"], str(dest.parent), dest.name,
        skip=True, control=control, progress_callback=progress_callback,
        expected_size=info["size"], use_part_file=True, timeout_value=30,
    )
    if not result:
        raise RuntimeError(f"Download failed/cancelled: {rel}")
    if sha256_file(dest, control=control).lower() != digest.lower():
        raise RuntimeError(f"SHA-256 verification failed: {rel}")
    print(f"[verified] {rel}")
    return True


def _install_group(group, control=None, progress_callback=None):
    downloaded=0
    total=len(group)
    for i,(rel,digest) in enumerate(group.items(),1):
        if control is not None and not control.wait_if_paused():
            raise RuntimeError("Q3Elite verification cancelled.")
        print(f"\n--- [{i}/{total}] {rel} ---")
        if _download_managed(rel,digest,control,progress_callback):
            downloaded+=1
    return downloaded


def is_true_fresh_install():
    """User-defined clean-install markers for the fast bulk path."""
    engines = ROOT / "Q3Elite" / "Engines"
    mus1n_pk3dir = ROOT / "baseq3" / "mods" / "osp" / "zzz-Mus1n.pk3dir"
    return not engines.exists() and not mus1n_pk3dir.exists()


def _basic_core_group(files):
    """Basic files physically stored inside the remote CORE folder."""
    return {
        rel: digest for rel, digest in selected_basic_files(files).items()
        if rel.casefold() not in BASE_MUSIC and classify(rel) != "basic_map"
    }


def _basic_missing_ratio(group):
    if not group:
        return 0.0
    missing = 0
    for rel in group:
        if not (ROOT / Path(rel)).is_file():
            missing += 1
    return missing / len(group)


def _zip_member_to_basic_path(member_name):
    """Map any safe Q3Elite_Basic.zip member to its GAME_ROOT-relative path."""
    raw = str(member_name).replace("\\", "/").lstrip("/")
    parts = list(PurePosixPath(raw).parts)
    if not parts:
        return None

    # pCloud may wrap the selected folder in one or more parent folders.
    # Prefer the known local roots wherever they occur in the archive path.
    for root_name in ("baseq3", "Q3Elite"):
        for i, part in enumerate(parts):
            if part.casefold() == root_name.casefold():
                parts = parts[i:]
                break
        else:
            continue
        break
    else:
        # Root-level files are normally wrapped by the selected pCloud folder.
        # Strip everything through the "Quake 3 Elite" folder when present.
        marker = None
        for i, part in enumerate(parts):
            if part.casefold() == "quake 3 elite":
                marker = i
        if marker is not None:
            parts = parts[marker + 1:]

    if not parts or any(part in ("", ".", "..") for part in parts):
        return None
    if any(":" in part for part in parts):
        return None

    rel = norm(str(PurePosixPath(*parts)))

    # FirstLaunch.bat belongs exclusively to Manual Installation.
    # The Launcher performs the equivalent setup itself, so never copy this
    # root-level batch file from the bulk Core/Basic archive.
    if rel.casefold() == "firstlaunch.bat":
        return None

    if rel.casefold().startswith("q3elite/launcher/"):
        # Launcher has its own self-update/cache lifecycle.  A cached Basic ZIP
        # must never downgrade the currently running launcher.
        return None
    return rel


def _extract_basic_zip(zip_path, group=None, control=None, progress_callback=None,
                       autoexec_update=False):
    """Extract the complete Basic payload; Manifest hashes are verified later."""
    extracted = set()
    root_resolved = ROOT.resolve()

    with zipfile.ZipFile(zip_path, "r") as zf:
        members = []
        for info in zf.infolist():
            if info.is_dir():
                continue
            rel = _zip_member_to_basic_path(info.filename)
            if not rel:
                continue
            dest = ROOT / Path(rel)
            try:
                dest.resolve().relative_to(root_resolved)
            except (ValueError, OSError):
                raise RuntimeError(f"Unsafe path in Q3Elite_Basic.zip: {info.filename}")
            members.append((info, rel, dest))

        if not members:
            sample = [i.filename for i in zf.infolist() if not i.is_dir()][:12]
            raise RuntimeError(
                "Q3Elite_Basic.zip contains no installable files. "
                "Archive sample: " + ", ".join(sample)
            )

        print(f"[bulk] Extracting complete Basic payload: {len(members)} files...")
        if progress_callback:
            progress_callback(0, None, 0.0, "Extracting Q3Elite_Basic.zip...")

        for info, rel, dest in members:
            if control is not None and not control.wait_if_paused():
                raise RuntimeError("Basic ZIP extraction cancelled.")
            # UserConfig is always user-owned after it exists. autoexec is also
            # user-owned when Autoexec Update is disabled.
            if is_user_config(rel) and dest.is_file():
                continue
            if (not autoexec_update and rel.casefold() == AUTOEXEC.casefold()
                    and dest.is_file()):
                continue
            dest.parent.mkdir(parents=True, exist_ok=True)
            with zf.open(info, "r") as srcf, dest.open("wb") as dstf:
                shutil.copyfileobj(srcf, dstf, length=16 * 1024 * 1024)
            extracted.add(rel.casefold())

    print(f"[bulk] Extracted complete payload: {len(extracted)} files")
    return len(extracted)


def _bulk_install_basic_core(files, control=None, progress_callback=None, autoexec_update=False):
    """
    Fresh-install accelerator.

    Downloads the remote Quake 3 Elite folder as one streamed pCloud ZIP.
    The ZIP is the installation payload, so every safe file is extracted except
    Q3Elite/Launcher (owned by the launcher self-updater). Manifest.json is used
    afterwards only to verify/repair files that Q3Elite intentionally manages.
    """
    group = _basic_core_group(files)
    if not group:
        return 0

    CACHE_DIR.mkdir(parents=True, exist_ok=True)

    # pCloud getpubzip is generated dynamically. A .part from a previous
    # launcher process cannot be trusted as a byte-prefix of a newly generated
    # ZIP stream, so explicitly discard it on a new fresh-install attempt.
    stale_part = BASIC_ZIP.with_name(BASIC_ZIP.name + ".part")
    if stale_part.exists():
        stale_size = stale_part.stat().st_size
        stale_part.unlink()
        print(
            f"[bulk] Previous dynamic ZIP partial found "
            f"({human(stale_size)}). Restarting bulk download from 0."
        )
    reuse_complete_zip = BASIC_ZIP.is_file() and zipfile.is_zipfile(BASIC_ZIP)
    if reuse_complete_zip:
        print(
            f"[bulk] Complete cached Basic ZIP found "
            f"({human(BASIC_ZIP.stat().st_size)}). Reusing it."
        )
    elif BASIC_ZIP.exists():
        print("[bulk] Cached Basic ZIP is invalid; removing it.")
        BASIC_ZIP.unlink()

    print("\nFresh Basic install detected.")
    print("Using pCloud bulk ZIP instead of thousands of individual requests...")
    print("The ZIP is streamed dynamically by pCloud.")
    print("Pause/Resume works in this launcher session; after launcher restart")
    print("the dynamic ZIP download starts from 0.")

    if reuse_complete_zip:
        if progress_callback:
            progress_callback(0, None, 0.0, "Using cached Q3Elite_Basic.zip...")
        result = str(BASIC_ZIP)
    else:
        if progress_callback:
            progress_callback(0, None, 0.0, "Preparing Q3Elite_Basic.zip...")
        url = pcloud.pubzip_url(pcloud.CORE, BASIC_ZIP.name)
        result = downloader(
            url,
            str(CACHE_DIR),
            BASIC_ZIP.name,
            skip=True,
            control=control,
            progress_callback=progress_callback,
            expected_size=None,
            use_part_file=True,
            timeout_value=20,
        )
        if not result:
            raise RuntimeError("Basic bulk ZIP download failed/cancelled.")

    archive = Path(result)
    with archive.open("rb") as fh:
        signature = fh.read(4)
    if signature not in (b"PK\x03\x04", b"PK\x05\x06", b"PK\x07\x08"):
        preview = archive.read_bytes()[:300]
        try:
            preview_text = preview.decode("utf-8", errors="replace").replace("\\r", " ").replace("\\n", " ")
        except Exception:
            preview_text = repr(preview)
        raise RuntimeError(
            "pCloud getpubzip did not return a ZIP archive. "
            f"First response bytes: {preview_text!r}"
        )

    try:
        extracted = _extract_basic_zip(
            archive, group, control, progress_callback,
            autoexec_update=autoexec_update,
        )
    except zipfile.BadZipFile as exc:
        # Preserve a bad archive only as .bad for diagnosis; fallback below can
        # still repair/download individual files.
        bad = BASIC_ZIP.with_suffix(".zip.bad")
        bad.unlink(missing_ok=True)
        try:
            os.replace(BASIC_ZIP, bad)
        except OSError:
            pass
        print(f"[bulk] Invalid ZIP: {exc}")
        return 0
    else:
        print(f"[bulk cache] Kept: {BASIC_ZIP}")
        return extracted



def _basic_map_member(member_name, wanted_cf):
    """Selected-file pCloud ZIP stores the 26 PK3 files at archive root."""
    name = PurePosixPath(norm(member_name)).name
    return wanted_cf.get((BASIC_QL_PREFIX + name).casefold())


def _extract_basic_maps_zip(zip_path, group, control=None):
    """Fast extraction of the required 26 maps. Verification is done afterwards."""
    wanted_cf = {norm(rel).casefold(): norm(rel) for rel in group}
    extracted = set()
    with zipfile.ZipFile(zip_path, "r") as zf:
        for info in zf.infolist():
            if info.is_dir():
                continue
            if control is not None and not control.wait_if_paused():
                raise RuntimeError("Basic Maps ZIP extraction cancelled.")
            rel = _basic_map_member(info.filename, wanted_cf)
            if not rel:
                continue
            dest = ROOT / Path(rel)
            dest.parent.mkdir(parents=True, exist_ok=True)
            with zf.open(info, "r") as srcf, dest.open("wb") as dstf:
                shutil.copyfileobj(srcf, dstf, length=16 * 1024 * 1024)
            extracted.add(rel.casefold())
    missing = [r for r in group if r.casefold() not in extracted]
    if missing:
        raise RuntimeError("Q3Elite_Basic_Maps.zip is missing: " + ", ".join(missing))
    print(f"[basic maps] Extracted: {len(extracted)} / {len(group)}")
    return extracted


def _resolve_basic_map_fileids(group):
    """Resolve exactly the 26 manifest paths; do not recursively enumerate Maps."""
    if not group:
        raise RuntimeError("No required Basic maps were selected from Manifest.json.")

    fileids = []
    for rel in group:
        remote = pcloud.remote_for(rel, is_map=True)
        entry = pcloud.find(remote)
        if entry.get("isfolder"):
            raise RuntimeError(f"Required map resolves to a folder: {remote}")
        fid = entry.get("fileid")
        if fid is None:
            raise RuntimeError(f"Required map has no pCloud fileid: {remote}")
        fileids.append(str(fid))

    if len(fileids) != len(BASIC_QL_MAP_NAMES):
        raise RuntimeError(
            f"Resolved {len(fileids)}/{len(BASIC_QL_MAP_NAMES)} required map file IDs."
        )
    return fileids


def _bulk_install_basic_maps(files, control=None, progress_callback=None):
    # The required Singleplayer set is authoritative for the bulk ZIP.
    # Manifest.json is allowed to contain fewer entries (currently 25/26); that
    # must not prevent the 26th required PK3 from being installed.  Preserve the
    # manifest spelling/hash where available and synthesize only the missing path.
    manifest_group = selected_basic_map_files(files)
    by_name = {PurePosixPath(norm(rel)).name.casefold(): (norm(rel), digest)
               for rel, digest in manifest_group.items()}
    group = {}
    missing_manifest = []
    for name_cf in sorted(BASIC_QL_MAP_NAMES):
        hit = by_name.get(name_cf)
        if hit:
            group[hit[0]] = hit[1]
        else:
            rel = BASIC_QL_PREFIX + name_cf
            group[rel] = None
            missing_manifest.append(rel)

    if missing_manifest:
        print(
            "[basic maps] Manifest has "
            f"{len(manifest_group)}/{len(BASIC_QL_MAP_NAMES)} required maps; "
            "the missing map(s) will still be included in the pCloud bulk ZIP: "
            + ", ".join(missing_manifest),
            flush=True,
        )

    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    part = BASIC_MAPS_ZIP.with_name(BASIC_MAPS_ZIP.name + ".part")
    part.unlink(missing_ok=True)

    reuse = BASIC_MAPS_ZIP.is_file() and zipfile.is_zipfile(BASIC_MAPS_ZIP)
    if BASIC_MAPS_ZIP.exists() and not reuse:
        BASIC_MAPS_ZIP.unlink()

    if reuse:
        print(f"[basic maps] Reusing cached {BASIC_MAPS_ZIP.name}")
        if progress_callback:
            progress_callback(0, None, 0.0, "Using cached Q3Elite_Basic_Maps.zip...")
        archive = BASIC_MAPS_ZIP
    else:
        print("[basic maps] Resolving 26 pCloud file IDs...")
        if progress_callback:
            progress_callback(0, None, 0.0, "Preparing Q3Elite_Basic_Maps.zip...")
        fileids = _resolve_basic_map_fileids(group)
        print(f"[basic maps] Creating ONE pCloud ZIP from {len(fileids)} files...")
        url = pcloud.pubzip_fileids_url(fileids, BASIC_MAPS_ZIP.name)
        result = downloader(
            url, str(CACHE_DIR), BASIC_MAPS_ZIP.name,
            skip=True, control=control, progress_callback=progress_callback,
            expected_size=None, use_part_file=True, timeout_value=60,
        )
        if not result:
            raise RuntimeError("Q3Elite_Basic_Maps.zip download failed/cancelled.")
        archive = Path(result)

    if not zipfile.is_zipfile(archive):
        raise RuntimeError("pCloud did not return a valid Q3Elite_Basic_Maps.zip.")
    if progress_callback:
        progress_callback(0, None, 0.0, "Extracting Q3Elite_Basic_Maps.zip...")
    return _extract_basic_maps_zip(archive, group, control)



def _create_vulkan_cinematic_shortcut():
    """Create the ROOT-level cinematic shortcut with detached playtime tracking."""
    engine_bat = ROOT / "Q3Elite" / "Engines" / "Q3Elite (Vulkan) - Cinematic.bat"
    icon_png = ROOT / "Q3Elite" / "Icons" / "b1.png"
    icon_ico = ROOT / "Q3Elite" / "Icons" / "b1.ico"
    shortcut = ROOT / "Q3Elite Vulkan Cinematic.lnk"
    tracked_bat = ROOT / "Q3Elite" / "Engines" / "Q3Elite (Vulkan) - Cinematic - Tracked.bat"

    if not engine_bat.is_file():
        print(f"[shortcut] Cinematic Vulkan batch not found; skipped: {engine_bat}")
        return False

    # Keep the original engine BAT untouched (it is manifest-managed). The
    # generated wrapper starts the same detached tracker used by Launch.pyw,
    # then delegates all game arguments to the original BAT.
    tracker = Path(__file__).resolve().with_name("game_session_tracker.py")
    tracker_python = Path(sys.executable).resolve()
    if tracker_python.name.casefold() == "python.exe":
        pythonw = tracker_python.with_name("pythonw.exe")
        if pythonw.is_file():
            tracker_python = pythonw

    target = engine_bat
    if tracker.is_file() and tracker_python.is_file():
        appdata = Path(os.environ.get("APPDATA", Path.home()))
        playtime_db = appdata / "Quake 3 Elite" / "Launcher" / "playtime.sqlite3"
        wrapper = """@echo off
setlocal
set "Q3E_TRACKER_PYTHON=__TRACKER_PYTHON__"
set "Q3E_TRACKER_SCRIPT=__TRACKER_SCRIPT__"
set "Q3E_TRACKER_DB=__TRACKER_DB__"
set "Q3E_ENGINE_BAT=__ENGINE_BAT__"
set "Q3E_IGNORE_PIDS="
for /f "usebackq delims=" %%P in (`powershell.exe -NoProfile -Command "$p = Get-Process -ErrorAction SilentlyContinue ^| Where-Object { $_.ProcessName -like '*xq3e*' }; if ($p) { ($p ^| ForEach-Object { $_.Id }) -join ',' }"`) do set "Q3E_IGNORE_PIDS=%%P"
if exist "%Q3E_TRACKER_PYTHON%" if exist "%Q3E_TRACKER_SCRIPT%" (
    start "" "%Q3E_TRACKER_PYTHON%" "%Q3E_TRACKER_SCRIPT%" --db "%Q3E_TRACKER_DB%" --ignore-pids "%Q3E_IGNORE_PIDS%" --wait-seconds 35 --heartbeat-seconds 60
)
call "%Q3E_ENGINE_BAT%" %*
endlocal
"""
        replacements = {
            "__TRACKER_PYTHON__": str(tracker_python),
            "__TRACKER_SCRIPT__": str(tracker),
            "__TRACKER_DB__": str(playtime_db),
            "__ENGINE_BAT__": str(engine_bat),
        }
        for marker, value in replacements.items():
            wrapper = wrapper.replace(marker, value.replace('"', '""'))
        try:
            tracked_bat.parent.mkdir(parents=True, exist_ok=True)
            tracked_bat.write_text(wrapper, encoding="utf-8", newline="\r\n")
            target = tracked_bat
            print(f"[shortcut] Playtime tracking wrapper created: {tracked_bat}")
        except OSError as error:
            print(f"[shortcut] Could not write tracking wrapper; using original BAT: {error}")
    else:
        missing = []
        if not tracker.is_file():
            missing.append(str(tracker))
        if not tracker_python.is_file():
            missing.append(str(tracker_python))
        print("[shortcut] Detached tracker unavailable; shortcut will launch game without tracking: "
              + ", ".join(missing))

    script = r"""
$ErrorActionPreference = 'Stop'
$target = $env:Q3E_VULKAN_TARGET
$workdir = Split-Path -Parent $target
$iconPng = $env:Q3E_VULKAN_ICON_PNG
$iconIco = $env:Q3E_VULKAN_ICON_ICO
$linkPath = $env:Q3E_VULKAN_LINK

if ((Test-Path -LiteralPath $iconPng) -and -not (Test-Path -LiteralPath $iconIco)) {
    Add-Type -AssemblyName System.Drawing
    $source = [System.Drawing.Image]::FromFile($iconPng)
    try {
        $sizes = @(16, 24, 32, 48, 64, 128, 256)
        $frames = New-Object System.Collections.Generic.List[byte[]]
        foreach ($size in $sizes) {
            $bmp = New-Object System.Drawing.Bitmap($size, $size, [System.Drawing.Imaging.PixelFormat]::Format32bppArgb)
            try {
                $g = [System.Drawing.Graphics]::FromImage($bmp)
                try {
                    $g.Clear([System.Drawing.Color]::Transparent)
                    $g.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
                    $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::HighQuality
                    $g.DrawImage($source, 0, 0, $size, $size)
                } finally { $g.Dispose() }
                $ms = New-Object System.IO.MemoryStream
                try { $bmp.Save($ms, [System.Drawing.Imaging.ImageFormat]::Png); $frames.Add($ms.ToArray()) }
                finally { $ms.Dispose() }
            } finally { $bmp.Dispose() }
        }
    } finally { $source.Dispose() }

    $ms = New-Object System.IO.MemoryStream
    $bw = New-Object System.IO.BinaryWriter($ms)
    try {
        $bw.Write([UInt16]0); $bw.Write([UInt16]1); $bw.Write([UInt16]$sizes.Count)
        $offset = 6 + 16 * $sizes.Count
        for ($i = 0; $i -lt $sizes.Count; $i++) {
            $dim = if ($sizes[$i] -eq 256) { [byte]0 } else { [byte]$sizes[$i] }
            $frame = $frames[$i]
            $bw.Write($dim); $bw.Write($dim); $bw.Write([byte]0); $bw.Write([byte]0)
            $bw.Write([UInt16]1); $bw.Write([UInt16]32)
            $bw.Write([UInt32]$frame.Length); $bw.Write([UInt32]$offset)
            $offset += $frame.Length
        }
        foreach ($frame in $frames) { $bw.Write($frame) }
        [IO.File]::WriteAllBytes($iconIco, $ms.ToArray())
    } finally { $bw.Dispose(); $ms.Dispose() }
}

$ws = New-Object -ComObject WScript.Shell
$link = $ws.CreateShortcut($linkPath)
$link.TargetPath = $target
$link.WorkingDirectory = $workdir
if (Test-Path -LiteralPath $iconIco) { $link.IconLocation = $iconIco + ',0' }
elseif (Test-Path -LiteralPath $iconPng) { Write-Host 'b1.ico was not created; shortcut will use the default icon.' }
$link.Save()
"""
    env = os.environ.copy()
    env.update({
        "Q3E_VULKAN_TARGET": str(target),
        "Q3E_VULKAN_ICON_PNG": str(icon_png),
        "Q3E_VULKAN_ICON_ICO": str(icon_ico),
        "Q3E_VULKAN_LINK": str(shortcut),
    })
    try:
        result = subprocess.run(
            ["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", script],
            env=env, capture_output=True, text=True, timeout=30,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
        if result.returncode != 0:
            detail = (result.stderr or result.stdout or "").strip()
            print(f"[shortcut] Could not create Vulkan Cinematic shortcut: {detail}")
            return False
        print(f"[shortcut] Created: {shortcut} -> {target.name}")
        return True
    except Exception as error:
        print(f"[shortcut] Could not create Vulkan Cinematic shortcut: {error}")
        return False


def install_basic(external_maps=False, music_playlist=False, autoexec_update=False,
                  control=None, progress_callback=None):
    control = control or DownloadControl()
    pending_state = load_state()
    was_complete = bool(pending_state.get("basic", False))

    # Saved component state is a preference/history flag, not proof that the
    # payload still exists.  If a core tree was deleted, force the cached bulk
    # ZIP recovery path instead of downloading Manifest entries one by one.
    baseq3_dir = ROOT / "baseq3"
    engines_dir = ROOT / "Q3Elite" / "Engines"
    qlmaps_dir = baseq3_dir / "maps" / "QLmaps"
    try:
        has_basic_map = qlmaps_dir.is_dir() and any(
            p.is_file() and p.suffix.casefold() == ".pk3"
            for p in qlmaps_dir.iterdir()
        )
    except OSError:
        has_basic_map = False
    physical_basic_ok = baseq3_dir.is_dir() and engines_dir.is_dir() and has_basic_map
    force_bulk_recovery = was_complete and not physical_basic_ok
    if force_bulk_recovery:
        print("[recovery] Saved Basic state is stale; core payload is missing.")
        print("[recovery] Reusing Basic ZIP caches instead of per-file Manifest repair.")

    pending_state["external_maps"] = bool(external_maps)
    pending_state["music_playlist"] = bool(music_playlist)
    pending_state["autoexec_update"] = bool(autoexec_update)
    save_state(pending_state)

    # Keep the proven old Basic path: obtain release metadata, then one Basic ZIP.
    # Report each network stage explicitly so the GUI never looks silently stuck.
    if progress_callback:
        progress_callback(0, None, 0.0, "Connecting to pCloud...")
    version, manifest, files = remote_release()
    basic = selected_basic_files(files, autoexec_update)

    # autoexec.cfg is a user-owned configuration when Autoexec Update is OFF.
    # It may be supplied by the bulk Basic ZIP on a clean install, but it must
    # not participate in the manifest repair pass because that would overwrite
    # the extracted/user copy and can fail if the pCloud copy intentionally
    # differs from Manifest.json.
    verify_basic = {
        rel: digest for rel, digest in basic.items()
        if autoexec_update or classify(rel) != "autoexec"
    }

    print("="*72)
    print(" Q3Elite Basic installation")
    print("="*72)
    print(f"Basic files: {len(basic)}")

    downloaded = 0
    bulk_extracted = 0

    if not was_complete or force_bulk_recovery:
        # A first install/recovery is a transaction. Creating Q3Elite/Engines halfway through
        # must NOT turn it into an update/repair installation.
        bulk_extracted = _bulk_install_basic_core(
            files, control, progress_callback,
            autoexec_update=autoexec_update,
        )
        print("[stage] Basic ZIP extraction finished.", flush=True)

        # Required Singleplayer maps are a second bulk archive, never 26 individual
        # downloads on first install.
        print("[stage] Starting required Basic Maps ZIP.", flush=True)
        _bulk_install_basic_maps(files, control, progress_callback)
        print("[stage] Basic Maps ZIP finished.", flush=True)

        # One normal manifest verification pass AFTER both bulk archives are
        # extracted. This is the same proven model used by the old launcher:
        # fast ZIP extraction first, then hash/repair the installed tree once.
        if progress_callback:
            progress_callback(0, None, 0.0, "Verifying Q3Elite Basic...")
        downloaded += _install_group(verify_basic, control, progress_callback)
    else:
        # Existing installation: normal manifest repair is appropriate.
        downloaded += _install_group(verify_basic, control, progress_callback)

    if external_maps:
        downloaded += _install_group(selected_map_files(files), control, progress_callback)

    atomic_json(LOCAL_MANIFEST, manifest)
    atomic_json(LOCAL_VERSION, version)

    # Core includes the cinematic Vulkan engine; expose its direct launcher
    # beside the game root after the core payload has been verified.
    _create_vulkan_cinematic_shortcut()

    state = load_state()
    state["basic"] = True
    state["external_maps"] = bool(external_maps)
    state["autoexec_update"] = bool(autoexec_update)
    save_state(state)

    if music_playlist:
        install_music(control, progress_callback)

    print("\n[OK] Basic ready.")
    print(f"Bulk extracted/verified: {bulk_extracted}")
    print(f"Individual downloads:    {downloaded}")
    return load_state()



def _external_map_catalog():
    """Live pCloud catalog for the independent External Maps addon.

    This intentionally does NOT read Manifest.json. The 26 Basic maps are
    owned by the Basic installer and are excluded by filename below.
    """
    items = pcloud.list_folder(pcloud.MAPS, recursive=True)
    result = []
    seen = set()
    for item in items:
        rel = norm(item.get("relative", ""))
        parts = PurePosixPath(rel).parts
        if not parts or any(part in ("", ".", "..") for part in parts):
            continue
        if ":" in rel or PurePosixPath(rel).suffix.casefold() != ".pk3":
            continue
        # The archive also contains the 26 Basic maps. They remain exclusively
        # managed by Manifest.json / Q3Elite_Basic_Maps.zip.
        if PurePosixPath(rel).name.casefold() in BASIC_QL_MAP_NAMES:
            continue
        key = rel.casefold()
        if key in seen:
            raise RuntimeError(f"Duplicate path in External Maps catalog: {rel}")
        seen.add(key)
        result.append({**item, "relative": rel})
    if not result:
        raise RuntimeError(
            f"No optional .pk3 maps found in pCloud addon folder: {pcloud.MAPS}"
        )
    return result


def _external_map_zip_relative(member_name, wanted):
    """Resolve a ZIP member to the exact pCloud-relative map path."""
    raw = str(member_name).replace("\\", "/").lstrip("/")
    parts = PurePosixPath(raw).parts
    if not parts or any(part in ("", ".", "..") for part in parts) or ":" in raw:
        return None
    candidates = [norm(raw)]
    for i, part in enumerate(parts):
        if part.casefold() in ("maps", "baseq3"):
            suffix_parts = parts[i + 1:]
            if suffix_parts and suffix_parts[0].casefold() == "maps":
                suffix_parts = suffix_parts[1:]
            if suffix_parts:
                candidates.append(norm(str(PurePosixPath(*suffix_parts))))
    for candidate in candidates:
        found = wanted.get(candidate.casefold())
        if found:
            return found
    return None


def _extract_external_maps_zip(zip_path, items, previously_owned=None, control=None):
    """Extract optional maps only; never touch the 26 Basic maps or user files."""
    wanted = {item["relative"].casefold(): item for item in items}
    previous = {norm(k).casefold() for k in (previously_owned or {})}
    extracted_hashes = {}
    root_resolved = ROOT.resolve()
    with zipfile.ZipFile(zip_path, "r") as zf:
        bad_member = zf.testzip()
        if bad_member:
            raise RuntimeError(f"Corrupt member in Q3Elite_Maps.zip: {bad_member}")
        for info in zf.infolist():
            if info.is_dir():
                continue
            item = _external_map_zip_relative(info.filename, wanted)
            if not item:
                continue
            rel = item["relative"]
            dest = ROOT / "baseq3" / "maps" / Path(*PurePosixPath(rel).parts)
            try:
                dest.resolve().relative_to(root_resolved)
            except (ValueError, OSError):
                raise RuntimeError(f"Unsafe path in Q3Elite_Maps.zip: {info.filename}")
            if dest.exists() and rel.casefold() not in previous:
                # Do not overwrite a map the user already had before enabling addon.
                print(f"[preserved existing] baseq3/maps/{rel}")
                continue
            dest.parent.mkdir(parents=True, exist_ok=True)
            tmp = dest.with_name(dest.name + ".maps.tmp")
            digest = hashlib.sha256()
            try:
                with zf.open(info, "r") as srcf, tmp.open("wb") as dstf:
                    while True:
                        if control is not None and not control.wait_if_paused():
                            raise RuntimeError("External Maps extraction cancelled.")
                        block = srcf.read(4 * 1024 * 1024)
                        if not block:
                            break
                        dstf.write(block)
                        digest.update(block)
                expected_size = int(item.get("size", 0) or 0)
                if expected_size and tmp.stat().st_size != expected_size:
                    raise RuntimeError(
                        f"External map size verification failed: {rel} "
                        f"({tmp.stat().st_size} != {expected_size})"
                    )
                os.replace(tmp, dest)
                extracted_hashes[rel] = digest.hexdigest()
            finally:
                tmp.unlink(missing_ok=True)
    if not extracted_hashes and not any(
        (ROOT / "baseq3" / "maps" / Path(*PurePosixPath(item["relative"]).parts)).is_file()
        for item in items
    ):
        raise RuntimeError("Q3Elite_Maps.zip contained no installable External Maps.")
    print(f"[maps bulk] Installed/verified optional maps: {len(extracted_hashes)}")
    return extracted_hashes


def _bulk_install_maps(items, control=None, progress_callback=None, previously_owned=None):
    if not items:
        raise RuntimeError("External Maps catalog is empty; nothing was installed.")
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    stale_part = MAPS_ZIP.with_name(MAPS_ZIP.name + ".part")
    if stale_part.exists():
        stale_size = stale_part.stat().st_size
        stale_part.unlink()
        print(f"[maps bulk] Removed stale partial ZIP ({human(stale_size)}).")

    reuse = MAPS_ZIP.is_file() and zipfile.is_zipfile(MAPS_ZIP)
    if reuse:
        with zipfile.ZipFile(MAPS_ZIP, "r") as zf:
            bad_member = zf.testzip()
        if bad_member:
            reuse = False
    if reuse:
        print(f"[maps bulk] Reusing valid cache: {MAPS_ZIP} ({human(MAPS_ZIP.stat().st_size)})")
    elif MAPS_ZIP.exists():
        print("[maps bulk] Cached Maps ZIP is invalid; removing it.")
        MAPS_ZIP.unlink()

    if not reuse:
        print("\\nDownloading External Maps as one pCloud ZIP...")
        if progress_callback:
            progress_callback(0, None, 0.0, "Preparing Q3Elite_Maps.zip...")
        url = pcloud.pubzip_url(pcloud.MAPS, MAPS_ZIP.name)
        result = downloader(
            url, str(CACHE_DIR), MAPS_ZIP.name, skip=True,
            control=control, progress_callback=progress_callback,
            expected_size=None, use_part_file=True, timeout_value=60,
        )
        if not result:
            raise RuntimeError("External Maps bulk ZIP download failed/cancelled.")
        archive = Path(result)
    else:
        archive = MAPS_ZIP

    if not zipfile.is_zipfile(archive):
        raise RuntimeError("pCloud did not return a valid Q3Elite_Maps.zip.")
    return _extract_external_maps_zip(archive, items, previously_owned, control)


def install_maps(control=None, progress_callback=None):
    """Install the optional pCloud Maps addon independently from the manifest."""
    ctl = control or DownloadControl()
    state = load_state()
    previous = state.get("external_maps_hashes", {})
    if not isinstance(previous, dict):
        previous = {}

    items = _external_map_catalog()
    print(f"\\nExternal Maps: {len(items)} optional PK3 files")
    hashes = _bulk_install_maps(items, ctl, progress_callback, previous)

    # Include files that were already installed by an earlier successful run,
    # but only while their current bytes still match the recorded addon hash.
    combined = {}
    for rel, digest in previous.items():
        path = ROOT / "baseq3" / "maps" / Path(*PurePosixPath(norm(rel)).parts)
        if path.is_file() and sha256_file(path, control=ctl).lower() == str(digest).lower():
            combined[norm(rel)] = str(digest).lower()
    combined.update(hashes)
    if not combined:
        raise RuntimeError("External Maps installation produced no verified addon files.")

    state["external_maps_hashes"] = combined
    state["external_maps"] = True
    save_state(state)
    print(f"\\n[OK] External Maps installed. Managed addon maps: {len(combined)}")


def uninstall_maps():
    """Remove only unchanged files previously installed by the External Maps addon."""
    state = load_state()
    known = state.get("external_maps_hashes", {})
    if not isinstance(known, dict):
        known = {}
    removed = modified = missing = 0
    for rel, digest in known.items():
        rel = norm(rel)
        parts = PurePosixPath(rel).parts
        if not parts or any(part in ("", ".", "..") for part in parts) or ":" in rel:
            print(f"[preserved unsafe state path] {rel}")
            modified += 1
            continue
        # Defensive guard: Basic maps are never addon-owned, even if old state is bad.
        if PurePosixPath(rel).name.casefold() in BASIC_QL_MAP_NAMES:
            print(f"[preserved Basic map] {rel}")
            modified += 1
            continue
        path = ROOT / "baseq3" / "maps" / Path(*parts)
        if not path.exists():
            missing += 1
            continue
        if path.is_file() and sha256_file(path).lower() == str(digest).lower():
            path.unlink()
            removed += 1
            print(f"[removed] baseq3/maps/{rel}")
        else:
            modified += 1
            print(f"[preserved modified] baseq3/maps/{rel}")
    state["external_maps"] = False
    state["external_maps_hashes"] = {}
    save_state(state)
    print(f"[OK] Maps removal: removed={removed}, preserved_modified={modified}, missing={missing}")


def install_music(control=None, progress_callback=None):
    result=music.install_optional(control or DownloadControl(), progress_callback)
    data=music.catalog()
    hashes={}
    for item in data["optional"]:
        rel=Path(*PurePosixPath(item["relative"]).parts)
        path=music.LOCAL_ROOT/rel
        if path.is_file():
            hashes[norm(str(PurePosixPath(item["relative"])))] = sha256_file(path)
    state=load_state()
    state["music_playlist"]=True
    state["music_hashes"]=hashes
    save_state(state)
    return result


def uninstall_music():
    state=load_state()
    known={norm(k).casefold():v.lower() for k,v in state.get("music_hashes",{}).items()}
    data=music.catalog()
    removed=modified=missing=0
    for item in data["optional"]:
        rel=norm(item["relative"])
        path=music.LOCAL_ROOT/Path(*PurePosixPath(rel).parts)
        if not path.exists():
            missing+=1; continue
        wanted=known.get(rel.casefold())
        # Delete only files whose SHA was recorded by our installer.
        if wanted and path.is_file() and sha256_file(path).lower()==wanted:
            path.unlink(); removed+=1; print(f"[removed] {rel}")
        else:
            modified+=1; print(f"[preserved unverified/modified] {rel}")
    state["music_playlist"]=False
    state["music_hashes"]={}
    save_state(state)
    print(f"[OK] Music removal: removed={removed}, preserved={modified}, missing={missing}")


def set_autoexec_update(enabled):
    state=load_state(); state["autoexec_update"]=bool(enabled); save_state(state)
    print(f"[OK] Autoexec Update: {'ON' if enabled else 'OFF'}")


def show_info():
    c=catalog(); s=load_state()
    total=c["basic_bytes"]
    print("="*72)
    print(" Q3Elite installation components — Step 18B")
    print("="*72)
    print(f"Quake 3 Elite Basic      {human(c['basic_bytes'])}  [required]")
    print(f"[ ] External Maps       +{human(c['maps_bytes'])}")
    print(f"[ ] Music Playlist      +{human(c['music_bytes'])} ({c['music_tracks']} tracks)")
    print(f"[ ] Autoexec Update      policy toggle ({human(c['autoexec_bytes'])} file)")
    print()
    print("Current component state:")
    print(json.dumps(s, indent=2))
    print(f"\nBasic-only download size (remote payload): {human(total)}")


def main():
    ap=argparse.ArgumentParser()
    sub=ap.add_subparsers(dest="cmd",required=True)
    sub.add_parser("info")
    ins=sub.add_parser("install")
    ins.add_argument("--maps",action="store_true")
    ins.add_argument("--music",action="store_true")
    ins.add_argument("--autoexec-update",action="store_true")
    sub.add_parser("install-maps")
    sub.add_parser("remove-maps")
    sub.add_parser("install-music")
    sub.add_parser("remove-music")
    ae=sub.add_parser("autoexec-update")
    ae.add_argument("value",choices=("on","off"))
    a=ap.parse_args()
    ctl=DownloadControl()
    if a.cmd=="info": show_info()
    elif a.cmd=="install": install_basic(a.maps,a.music,a.autoexec_update,ctl)
    elif a.cmd=="install-maps": install_maps(ctl)
    elif a.cmd=="remove-maps": uninstall_maps()
    elif a.cmd=="install-music": install_music(ctl)
    elif a.cmd=="remove-music": uninstall_music()
    elif a.cmd=="autoexec-update": set_autoexec_update(a.value=="on")

if __name__=="__main__":
    main()
